window.VE_TESTDIR = mw.config.get( 'wgExtensionAssetsPath' ) + '/VisualEditor/modules/ve/test';
