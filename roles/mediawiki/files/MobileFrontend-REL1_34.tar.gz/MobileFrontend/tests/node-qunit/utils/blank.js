// This file is loaded instead of mockMediaWiki.js when using MW test runner
module.exports = function () {
};
