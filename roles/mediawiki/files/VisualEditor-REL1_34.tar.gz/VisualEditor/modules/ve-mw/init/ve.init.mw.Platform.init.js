/*!
 * VisualEditor MediaWiki Platform init.
 *
 * @copyright 2011-2019 VisualEditor Team and others; see AUTHORS.txt
 * @license The MIT License (MIT); see LICENSE.txt
 */

// eslint-disable-next-line no-new
new ve.init.mw.Platform();
